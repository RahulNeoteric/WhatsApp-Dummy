import type { SupabaseClient } from '@supabase/supabase-js'

export function isMockMode(): boolean {
  if (process.env.NEXT_PUBLIC_MOCK_SUPABASE === 'true') return true
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  if (!url || url.includes('placeholder') || url.includes('your-project') || url.includes('example')) {
    return true
  }
  return false
}

export const MOCK_USER = {
  id: 'demo-user-123',
  email: 'admin@demo.local',
  user_metadata: { full_name: 'Demo Admin' },
  app_metadata: {},
  aud: 'authenticated',
  created_at: new Date().toISOString(),
}

export const MOCK_SESSION = {
  access_token: 'mock-access-token',
  token_type: 'bearer',
  expires_in: 3600,
  refresh_token: 'mock-refresh-token',
  user: MOCK_USER,
}

export const MOCK_PROFILE = {
  id: 'demo-profile-123',
  user_id: 'demo-user-123',
  full_name: 'Demo Admin',
  email: 'admin@demo.local',
  avatar_url: null,
  role: 'admin',
  beta_features: [],
  account_id: 'demo-account-123',
  account_role: 'owner',
}

export const MOCK_ACCOUNT = {
  id: 'demo-account-123',
  name: 'Demo WACRM (Local Mode)',
  default_currency: 'USD',
  created_at: new Date().toISOString(),
}

export const MOCK_CONTACTS = [
  {
    id: 'c1',
    account_id: 'demo-account-123',
    name: 'Alice Smith',
    phone: '+15550192834',
    email: 'alice@example.com',
    custom_fields: {},
    notes: 'Key customer lead',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'c2',
    account_id: 'demo-account-123',
    name: 'Bob Jones',
    phone: '+15550192835',
    email: 'bob@example.com',
    custom_fields: {},
    notes: 'Interested in enterprise plan',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'c3',
    account_id: 'demo-account-123',
    name: 'Charlie Brown',
    phone: '+15550192836',
    email: 'charlie@example.com',
    custom_fields: {},
    notes: 'Follow up next week',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

export const MOCK_CONVERSATIONS = [
  {
    id: 'conv1',
    account_id: 'demo-account-123',
    contact_id: 'c1',
    status: 'open',
    unread_count: 1,
    last_message_at: new Date().toISOString(),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    contact: MOCK_CONTACTS[0],
  },
  {
    id: 'conv2',
    account_id: 'demo-account-123',
    contact_id: 'c2',
    status: 'open',
    unread_count: 0,
    last_message_at: new Date().toISOString(),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    contact: MOCK_CONTACTS[1],
  },
]

export const MOCK_MESSAGES = [
  {
    id: 'm1',
    account_id: 'demo-account-123',
    conversation_id: 'conv1',
    contact_id: 'c1',
    body: 'Hello! I have a question regarding pricing.',
    direction: 'inbound',
    status: 'delivered',
    created_at: new Date().toISOString(),
  },
  {
    id: 'm2',
    account_id: 'demo-account-123',
    conversation_id: 'conv1',
    contact_id: 'c1',
    body: 'Hi Alice! We would be happy to help you with pricing information.',
    direction: 'outbound',
    status: 'read',
    created_at: new Date().toISOString(),
  },
]

export const MOCK_PIPELINES = [
  {
    id: 'p1',
    account_id: 'demo-account-123',
    name: 'Sales Pipeline',
    currency: 'USD',
    is_default: true,
    created_at: new Date().toISOString(),
  },
]

export const MOCK_STAGES = [
  { id: 's1', pipeline_id: 'p1', name: 'New Lead', position: 0 },
  { id: 's2', pipeline_id: 'p1', name: 'Qualified', position: 1 },
  { id: 's3', pipeline_id: 'p1', name: 'Proposal Sent', position: 2 },
  { id: 's4', pipeline_id: 'p1', name: 'Closed Won', position: 3 },
]

export const MOCK_DEALS = [
  {
    id: 'd1',
    account_id: 'demo-account-123',
    pipeline_id: 'p1',
    stage_id: 's2',
    contact_id: 'c1',
    title: 'Acme Enterprise License',
    value: 5000,
    currency: 'USD',
    created_at: new Date().toISOString(),
    contact: MOCK_CONTACTS[0],
  },
]

export const MOCK_TAGS = [
  { id: 't1', account_id: 'demo-account-123', name: 'VIP', color: '#3b82f6' },
  { id: 't2', account_id: 'demo-account-123', name: 'Hot Lead', color: '#ef4444' },
]

export function getMockTableData(table: string): any[] {
  switch (table) {
    case 'profiles':
      return [MOCK_PROFILE]
    case 'accounts':
      return [MOCK_ACCOUNT]
    case 'contacts':
      return MOCK_CONTACTS
    case 'conversations':
      return MOCK_CONVERSATIONS
    case 'messages':
      return MOCK_MESSAGES
    case 'pipelines':
      return MOCK_PIPELINES
    case 'pipeline_stages':
    case 'stages':
      return MOCK_STAGES
    case 'deals':
      return MOCK_DEALS
    case 'tags':
    case 'contact_tags':
      return MOCK_TAGS
    default:
      return []
  }
}

export function createMockQueryBuilder(table: string, isSingle = false) {
  const dataList = getMockTableData(table)
  const resultData = isSingle ? (dataList[0] ?? null) : dataList
  const response = {
    data: resultData,
    error: null,
    count: dataList.length,
    status: 200,
    statusText: 'OK',
  }

  const builder: any = {
    then(onFulfilled?: any, onRejected?: any) {
      return Promise.resolve(response).then(onFulfilled, onRejected)
    },
    catch(onRejected?: any) {
      return Promise.resolve(response).catch(onRejected)
    },
    single() {
      return createMockQueryBuilder(table, true)
    },
    maybeSingle() {
      return createMockQueryBuilder(table, true)
    },
  }

  const handler: ProxyHandler<any> = {
    get(target, prop, receiver) {
      if (prop in target) {
        return target[prop]
      }
      if (typeof prop === 'symbol') return undefined
      return (..._args: any[]) => {
        if (prop === 'single' || prop === 'maybeSingle') {
          return createMockQueryBuilder(table, true)
        }
        return new Proxy(builder, handler)
      }
    },
  }

  return new Proxy(builder, handler)
}

export function createMockClient(): SupabaseClient {
  const baseClient = {
    auth: {
      async getSession() {
        return { data: { session: MOCK_SESSION }, error: null }
      },
      async getUser() {
        return { data: { user: MOCK_USER }, error: null }
      },
      async signInWithPassword() {
        return { data: { user: MOCK_USER, session: MOCK_SESSION }, error: null }
      },
      async signOut() {
        return { error: null }
      },
      onAuthStateChange(cb: any) {
        if (typeof cb === 'function') {
          setTimeout(() => cb('SIGNED_IN', MOCK_SESSION), 0)
        }
        return { data: { subscription: { unsubscribe: () => {} } } }
      },
      async setSession() {
        return { data: { session: MOCK_SESSION }, error: null }
      },
    },
    from(table: string) {
      return createMockQueryBuilder(table)
    },
    rpc() {
      return Promise.resolve({ data: [], error: null })
    },
    channel() {
      return {
        subscribe(cb?: any) {
          if (cb) setTimeout(() => cb('SUBSCRIBED'), 0)
          return { unsubscribe: () => {} }
        },
        unsubscribe() {},
        send() { return Promise.resolve('ok') },
        on() { return this },
      }
    },
    removeChannel() {
      return Promise.resolve('ok')
    },
    storage: {
      from() {
        return {
          upload: () => Promise.resolve({ data: { path: 'demo' }, error: null }),
          getPublicUrl: () => ({ data: { publicUrl: '/placeholder.svg' } }),
          download: () => Promise.resolve({ data: new Blob(), error: null }),
          list: () => Promise.resolve({ data: [], error: null }),
          remove: () => Promise.resolve({ data: [], error: null }),
        }
      },
    },
  }

  return baseClient as unknown as SupabaseClient
}
